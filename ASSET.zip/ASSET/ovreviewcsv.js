////csv file
$(document).ready(function() {
    $('#uploadBtn').on('click', function() {
      var fileInput = $('#csvFile')[0];
      var file = fileInput.files[0];

      if (file) {
        var formData = new FormData();
        formData.append('csvFile', file);

        $.ajax({
          url: "http://localhost:9090/upload",
          type: 'POST',
          data: formData,
          processData: false,
          contentType: false,
          success: function(response) {
            $('#message').text('File uploaded successfully.');
          },
          error: function(error) {
            $('#message').text('Error uploading file.');
          }
        });
      }
    });
  });