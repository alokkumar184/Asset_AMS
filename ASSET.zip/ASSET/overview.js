$(document).ready(function() {
    console.log("document ready");
    load_data();
  
    function load_data() {
      console.log("Loading");
    
      $.ajax({
        url: "http://localhost:9090/Allassets",
        method: "POST",
        data: { action: 'fetch' },
        dataType: "JSON",
        success: function(data) {
          var html = '';
  
          for (let i = 0; i < data.length; i++) {
            html += `
              <tr>
                <td>${data[i].asset_id}</td>
                <td>${data[i].asset_type}</td>
                <td>${data[i].asset_name}</td>
                <td>${data[i].dept_name}</td>
                <td>${data[i].emp_name}</td>
                <td>${data[i].emp_no}</td>
                <td>${data[i].location_name}</td>
                <td><button class="btn-info edit-btn">Edit</button></td>
              </tr>
            `;
          }
  
          $(".table-body").html(html);
        }
      });
    }
  
    $(document).on("click", ".edit-btn", function() {
      //var asset_id = $(this).closest('tr'); //.find('.table-body').text();
      //console.log($(this));

      //find the closest tr for the clicked edit btn
      let trElement = $(this).closest('tr');
      //console.log(trElement);
    
      //find all the td elements in the trElement
      let tdArray = trElement[0].getElementsByTagName('td');

      //select 1st td for asset_id and 2nd td element for asset type
      let asset_id = tdArray[0].innerText;
      let asset_type = tdArray[1].innerText;
      let asset_name = tdArray[2].innerText;
      let dept_name = tdArray[3].innerText;
      let emp_name = tdArray[4].innerText;
      let emp_no = tdArray[5].innerText;
      let location_name = tdArray[6].innerText;

      console.log('asset_id on click: ' + asset_id + ' '+ asset_type);
  

      call_edit_registration_popup($(this), asset_id, asset_type, asset_name, dept_name, emp_name, emp_no, location_name);

      // Make an AJAX request to fetch the edit form content
      // $.ajax({
      //   url: "http://localhost:9090/edit",
      //   method: "POST",
      //   data: { asset_id: asset_id,
      //           asset_type: asset_type,
      //   },
      //   success: function(response) {
      //     console.log(response);
      //     $('#edit-popup').html(response.data.asset_id);
      //     $('#edit-popup').show();
      //   },
      //   error: function() {
      //     alert('Error occurred while loading the edit form.');
      //   }
      // });
    });
  });

  function call_edit_registration_popup(e, asset_id, asset_type, asset_name, dept_name, emp_name, emp_no, location_name){
    let thisBtn = $(e);
    console.log(thisBtn[0]);
    
    let editBtn = thisBtn[0]; //document.getElementsByClassName('edit-btn');
    // select the modal-background
    let modalBackgroundEdit = document.getElementById('modal-background-edit-asset');
    // select the close-btn 
    let closeBtnEdit = document.getElementById('close-btn-edit-asset');

    // shows the modal when the user clicks open-btn
    modalBackgroundEdit.style.display = 'block';

    //set values to the fields in edit registration form
    $('#asset-id-edit-asset').val(asset_id);
    $('#asset-type-edit-asset').val(asset_type);
    $('#asset-name-edit-asset').val(asset_name);
    $('#department-name-edit-asset').val(dept_name);
    $('#employee-name-edit-asset').val(emp_name);
    $('#employee-id-edit-asset').val(emp_no);
    $('#asset-location-edit-asset').val(location_name);
    // hides the modal when the user clicks close-btn
    closeBtnEdit.addEventListener('click', function () {
        modalBackgroundEdit.style.display = 'none';
    });

    // hides the modal when the user clicks outside the modal
    window.addEventListener('click', function (event) {
        // check if the event happened on the modal-background
        if (event.target === modalBackgroundEdit) {
            // hides the modal
            modalBackgroundEdit.style.display = 'none';
        }
    });
}



  