const express = require('express');
const bodyParser = require('body-parser');
const sql = require('mssql');
const cors = require('cors');
const multer = require('multer');
const csvParser = require('csv-parser');
const fs = require('fs');
let dotenv = require('dotenv');
dotenv.config();
let port=process.env.PORT||8080;

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(
    cors({
        origin: '*',
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        allowHeaders: ['Content-Type']
    })
);

app.set('view engine', 'ejs');
app.set('views','views');

const config = {
    server: '10.0.2.18',
    user: 'SA',
    password: 'Soulsvciot01',
    database: 'asset',
    options: {
        encrypt: false,
        trustServerCertificate: false
    }
};



sql.connect(config, (err, result) => {
    if (err) throw err
    else {
        console.log('Connected to DB');
    }
})

app.post('/AllAssets', (req, res) => {

    let query = `select  top(1000) a.asset_id, a.asset_type,a.asset_name,d.dept_name,CONCAT(e.first_name,'',e.middle_name,'',e.last_name) as emp_name,e.emp_no,l.location_name
    from asset.dbo.assets a
    inner join  asset.dbo.department d on a.dept_id =d.dept_id
    inner join asset.dbo.Employees e on e.dept_work = d.dept_name
    inner join asset.dbo.location l on l.location_id =d.location_id`;
    let queryResult = sql.query(query, (err, result) => {
        if (err) {
            console.log('Error in All assets query');
        }
        else {
           
            console.log(result.recordset);
            // console.log(result.recordset[0].asset_id)
            res.send(result.recordset);         
        }
    })
})


app.get('/assetSort', (req, res) => {

    let query = `SELECT top(5) asset_id, asset_type,asset_name,dept_name FROM assets INNER JOIN department ON assets.dept_id = department.dept_id WHERE department.dept_name = 'COMMON ELECTRONICS ENGG' AND asset_type = 'Machinery & Lab Equipments'`;
    let query1 = `select distinct dept_name from dbo.department;`
    let query2 = `select distinct asset_type from dbo.assets`

    // if (criteria != null && crieria != ''){
    //     query += "and"
    // }

    let queryResult = sql.query(query, (err, result0) => {
        if (err) {
            console.log('Error in /assetSort1 in query');
        }
        else {

            // console.log(result.recordset);
            // res.send(result.recordset);
            // console.log(dn);
            let queryResult1 = sql.query(query1, (err, result1) => {
                if (err) {
                    console.log('Error in /assetSort2 in query');
                }
                else {

                    // console.log(result.recordset);
                    // res.send(result.recordset);
                    // console.log(dn);
                    let queryResult2 = sql.query(query2, (err, result2) => {
                        if (err) {
                            console.log('Error in /assetSort3 in query');
                        }
                        else {

                            // console.log(result.recordset);
                            // res.send(result.recordset);
                            // console.log(dn);

                            let val0 = Object.values(result0.recordset);
                            let val1 = Object.values(result1.recordset);
                            let val2 = Object.values(result2.recordset);
                            res.send(val0, val1, val2)
                            console.log(val0)
                            console.log(val1)
                            console.log(val2)
                        }
                    })

                }
            })
        }
    })

})


//edit asset information

app.post('/edit', (req, res) => {
    console.log('request info' + req.body);
    res.status(200).json({message: 'Edit api called', data: req.body});
})

///    csv upload 
const storage = multer.diskStorage({
    destination: function(req, file, cb) {
      cb(null, 'uploads/');
    },
    filename: function(req, file, cb) {
      cb(null, file.originalname);
    }
  });
  const upload = multer({ storage });
  
 
  app.post('/upload', upload.single('csvFile'), function(req, res) {
    const filePath = req.file.path;
    fs.createReadStream(filePath)
      .pipe(csvParser())
      .on('data', function(row) {
        console.log(row);
        let data1=Object.assign({},row);
        let data2=Object.assign({},row);
        // for(let i=0; i<Object.keys(row).length; i++){
        //    data1.push(Object.values(row[i]));
        //    data2.push(Object.values(row[i]));
        // }

        // for(const values in row) {
        //   data1.push(`${values}:${row[values]}`);
        //   data2.push(`${values}:${row[values]}`);
        // }
     
        console.log(data1, data2);

        insertDataToDatabase1(data1);
        insertDataToDatabase2(data2);
      })
      .on('end', function() {
        res.sendStatus(200);
      })
      .on('error', function(error) {
        res.sendStatus(500);
      });
  });



  function insertDataToDatabase1(data1) {
      sql.query(`INSERT INTO Users (user_id, user_name,email,password,user_type,Parent_org,Address) VALUES ('${data1.user_id}', '${data1.first_name} ${data1.middle_name} ${data1.last_name}', '${data1.email}','${data1.password}','${data1.user_type}','${data1.Parent_org}','${data1.Address}')`, function(err) {
         if (err) {
            console.error('Error inserting data into the database1: ', err);
         }
  });
}

function insertDataToDatabase2(data2) {
  sql.query(`INSERT INTO Employees(first_name,middle_name,last_name,dept_work,contact_no,Parent_org,emp_no) VALUES ('${data2.first_name}', '${data2.middle_name}', '${data2.last_name}','${data2.dept_work}','${data2.contact_no}','${data2.Parent_org}','${data2.user_id}')`, function(err) {
    if (err) {
       console.error('Error inserting data into the database2: ', err);
    }
  });
}


// Start the server on port 3000
app.listen(port, function () {
    console.log(`Server running on port ${port}`);
});