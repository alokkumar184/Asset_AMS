
///Date :-  25/05/2023

var people = [
    { FirstName:'     ' ,  Lastname :' ', Location: ' ', address: ' ', EmployeeId: ' ', Email_ID: ' ', Contact_Number: ' ' }
    
  ];

  
  function createCSV(array){
    var keys = Object.keys(array[0]); //Collects Table Headers
    
    var result = ''; //CSV Contents
    result += keys.join(','); //Comma Seperates Headers
    result += '\n'; //New Row
    
    array.forEach(function(item){ //Goes Through Each Array Object
      keys.forEach(function(key){//Goes Through Each Object value
        result += item[key] + ','; //Comma Seperates Each Key Value in a Row
      })
      result += '\n';//Creates New Row
    })
    
    return result;
  }
  
  
  function downloadCSV(array) {
    csv = 'data:text/csv;charset=utf-8,' + createCSV(array); //Creates CSV File Format
    excel = encodeURI(csv); //Links to CSV 
  
    link = document.createElement('a');
    link.setAttribute('href', excel); //Links to CSV File 
    link.setAttribute('download', 'test.csv'); //Filename that CSV is saved as
    link.click();
  }



  /**   javacsript for show the upload bar-----   25-03-2023*/
